===== Herittage Shop =====

Herittage Shop plugin adds shop features for Herittage theme.


== Changelog ==

= 1.0.0 =

    * First release!