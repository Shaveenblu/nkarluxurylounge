======= Herittage Plus =====

Herittage Plus plugin adds additonal features for Herittage theme.


== Changelog ==

= 1.0.1 =

    * Importer error fixed

= 1.0.0 =

    * First release!