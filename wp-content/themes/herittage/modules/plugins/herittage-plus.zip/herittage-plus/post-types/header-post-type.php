<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if (! class_exists ( 'HerittagePlusHeaderPostType' ) ) {

	class HerittagePlusHeaderPostType {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

		function __construct() {

			add_action ( 'init', array( $this, 'herittage_register_cpt' ), 5 );
			add_filter ( 'template_include', array ( $this, 'herittage_template_include' ) );
		}

		function herittage_register_cpt() {

			$labels = array (
				'name'				 => __( 'Headers', 'herittage-plus' ),
				'singular_name'		 => __( 'Header', 'herittage-plus' ),
				'menu_name'			 => __( 'Headers', 'herittage-plus' ),
				'add_new'			 => __( 'Add Header', 'herittage-plus' ),
				'add_new_item'		 => __( 'Add New Header', 'herittage-plus' ),
				'edit'				 => __( 'Edit Header', 'herittage-plus' ),
				'edit_item'			 => __( 'Edit Header', 'herittage-plus' ),
				'new_item'			 => __( 'New Header', 'herittage-plus' ),
				'view'				 => __( 'View Header', 'herittage-plus' ),
				'view_item' 		 => __( 'View Header', 'herittage-plus' ),
				'search_items' 		 => __( 'Search Headers', 'herittage-plus' ),
				'not_found' 		 => __( 'No Headers found', 'herittage-plus' ),
				'not_found_in_trash' => __( 'No Headers found in Trash', 'herittage-plus' ),
			);

			$args = array (
				'labels' 				=> $labels,
				'public' 				=> true,
				'exclude_from_search'	=> true,
				'show_in_nav_menus' 	=> false,
				'show_in_rest' 			=> true,
				'menu_position'			=> 25,
				'menu_icon' 			=> 'dashicons-heading',
				'hierarchical' 			=> false,
				'supports' 				=> array ( 'title', 'editor', 'revisions' ),
			);

			register_post_type ( 'wdt_headers', $args );
		}

		function herittage_template_include($template) {
			if ( is_singular( 'wdt_headers' ) ) {
				if ( ! file_exists ( get_stylesheet_directory () . '/single-wdt_headers.php' ) ) {
					$template = Herittage_PLUS_DIR_PATH . 'post-types/templates/single-wdt_headers.php';
				}
			}

			return $template;
		}
	}
}

HerittagePlusHeaderPostType::instance();