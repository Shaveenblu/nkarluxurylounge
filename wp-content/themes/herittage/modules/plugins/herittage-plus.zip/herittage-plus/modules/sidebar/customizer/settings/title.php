<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'HerittagePlusWidgetTitleSettings' ) ) {
    class HerittagePlusWidgetTitleSettings {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_action( 'customize_register', array( $this, 'register' ), 15);
        }

        function register( $wp_customize ){

            /**
             * Title Section
             */
            $wp_customize->add_section(
                new Herittage_Customize_Section(
                    $wp_customize,
                    'site-widgets-title-style-section',
                    array(
                        'title'    => esc_html__('Widget Title', 'herittage-plus'),
                        'panel'    => 'site-widget-settings-panel',
                        'priority' => 5,
                    )
                )
            );

            if ( ! defined( 'Herittage_PRO_VERSION' ) ) {
                $wp_customize->add_control(
                    new Herittage_Customize_Control_Separator(
                        $wp_customize, Herittage_CUSTOMISER_VAL . '[herittage-plus-site-sidebar-title-separator]',
                        array(
                            'type'        => 'wdt-separator',
                            'section'     => 'site-widgets-title-style-section',
                            'settings'    => array(),
                            'caption'     => Herittage_PLUS_REQ_CAPTION,
                            'description' => Herittage_PLUS_REQ_DESC,
                        )
                    )
                );
            }

        }

    }
}

HerittagePlusWidgetTitleSettings::instance();