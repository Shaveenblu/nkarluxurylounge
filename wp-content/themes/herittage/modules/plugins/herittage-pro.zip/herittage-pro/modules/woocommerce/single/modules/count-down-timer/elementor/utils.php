<?php

/*
* Update Summary - Options Filter
*/

if( ! function_exists( 'herittage_shop_woo_single_summary_options_cherittage_render' ) ) {
	function herittage_shop_woo_single_summary_options_cherittage_render( $options ) {

		$options['countdown'] = esc_html__('Summary Count Down', 'herittage-pro');
		return $options;

	}
	add_filter( 'herittage_shop_woo_single_summary_options', 'herittage_shop_woo_single_summary_options_cherittage_render', 10, 1 );

}

/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'herittage_shop_woo_single_summary_styles_cherittage_render' ) ) {
	function herittage_shop_woo_single_summary_styles_cherittage_render( $styles ) {

		array_push( $styles, 'wdt-shop-coundown-timer' );
		return $styles;

	}
	add_filter( 'herittage_shop_woo_single_summary_styles', 'herittage_shop_woo_single_summary_styles_cherittage_render', 10, 1 );

}

/*
* Update Summary - Scripts Filter
*/

if( ! function_exists( 'herittage_shop_woo_single_summary_scripts_cherittage_render' ) ) {
	function herittage_shop_woo_single_summary_scripts_cherittage_render( $scripts ) {

		array_push( $scripts, 'jquery-downcount' );
		array_push( $scripts, 'wdt-shop-coundown-timer' );
		return $scripts;

	}
	add_filter( 'herittage_shop_woo_single_summary_scripts', 'herittage_shop_woo_single_summary_scripts_cherittage_render', 10, 1 );

}