<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="pagination blog-pagination"><?php echo herittage_pagination(); ?></div>