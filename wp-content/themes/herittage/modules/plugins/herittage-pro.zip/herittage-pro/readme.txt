===== Herittage Pro =====

Herittage Pro plugin adds advanced features for Herittage theme.


== Changelog ==

= 1.0.1 =

    * Deprecated Errors Fixed

= 1.0.0 =

    * First release!