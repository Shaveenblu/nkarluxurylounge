<?php
if (! class_exists ( 'DTWPHBExtra' )) {
	class DTWPHBExtra {

		/**
		 * A function constructor calls initially
		 */
		function __construct() {

			define( 'CS_ACTIVE_TAXONOMY', true );

			// Add Hook into the 'init()' action
			add_action ( 'init', array (
				$this,
				'dt_init'
			) );

			// Add Hook into the 'admin_init()' action
			add_action ( 'admin_init', array (
				$this,
				'dt_admin_init'
			) );

			// Add Hook into the 'cs_taxonomy_options' filter
			add_filter ( 'cs_taxonomy_options', array (
				$this,
				'dt_hb_room_cs_taxonomy_options'
			) );
		}

		/**
		 * A function hook that the WordPress core launches at 'init' points
		 */
		function dt_init() {
			$this->createTaxonomy();
		}

		/**
		 * A function hook that the WordPress core launches at 'admin_init' points
		 */
		function dt_admin_init() {
			add_filter ( 'manage_edit-hb_room_columns', array (
				$this,
				'dt_hb_room_edit_columns'
			) );
		}

		/**
		 */
		function createTaxonomy() {
			$singular_name  = __('Facility', 'herittage-pro');
			$plural_name  	= __('Room Facilities', 'herittage-pro');

			if( function_exists( 'cs_get_option' ) ) :
				$singular_name  =	cs_get_option( 'singular-hb-facility-name', __('Facility', 'herittage-pro') );
				$plural_name	=	cs_get_option( 'plural-hb-facility-name', __('Room Facilities', 'herittage-pro') );
			endif;

			// HB Room Tags
			$labels = array(
				'name'              => $plural_name,
				'singular_name'     => $singular_name,
				'search_items'      => esc_html__( 'Search', 'herittage-pro' ).' '.$plural_name,
				'all_items'         => esc_html__( 'All', 'herittage-pro' ).' '.$plural_name,
				'parent_item'       => esc_html__( 'Parent', 'herittage-pro' ).' '.$singular_name,
				'parent_item_colon' => esc_html__( 'Parent', 'herittage-pro' ).' '.$singular_name.':',
				'edit_item'         => esc_html__( 'Edit', 'herittage-pro' ).' '.$singular_name,
				'update_item'       => esc_html__( 'Update', 'herittage-pro' ).' '.$singular_name,
				'add_new_item'      => esc_html__( 'Add New', 'herittage-pro' ).' '.$singular_name,
				'new_item_name'     => esc_html__( 'New', 'herittage-pro' ).' '.$singular_name.' '.esc_html__('Name', 'herittage-pro'),
				'menu_name'         => $plural_name,
			);

			register_taxonomy ( 'hb_room_facility', array (
				'hb_room'
			), array (
				'hierarchical' 		=> false,
				'labels' 			=> $labels,
				'show_admin_column' => true,
				'rewrite' 			=> array( 'slug' => 'hb_room_facility' ),
				'query_var' 		=> true
			) );
		}

		/**
		 * HB taxonomy options
		 */
		function dt_hb_room_cs_taxonomy_options( $options ) {

			$options[]   = array(
			  'id'       => '_room_facilities',
			  'taxonomy' => 'hb_room_facility',
			  'fields'   => array(

				array(
				  'id'        => 'facility_icon',
				  'type'      => 'image',
				  'title'     => esc_html__('Icon', 'herittage-pro'),
				  'after'  	  => '<p class="description">'.esc_html__('Click button to insert facility Icon.', 'herittage-pro').'</p>',
				  'add_title' => esc_html__('Add Icon', 'herittage-pro')
				),

			  ),
			);

			return $options;
		}

		/**
		 * HB room edit columns
		 */
		function dt_hb_room_edit_columns($columns) {

			unset( $columns['taxonomy-hb_room_facility'] );
			return $columns;
		}
	}
}
?>